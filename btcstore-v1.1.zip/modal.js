$(document).ready(function() {
    // Trigger the modal to show/hide
    $('#viewCartButton').click(function() {
        $('#cartModal').modal('toggle');
    });

    // More modal related operations
});